#if defined(RENDERTYPE_TEXT) || defined(RENDERTYPE_TEXT_INTENSITY)

struct TextData {
    vec4 color;
    vec4 topColor;
    vec4 backColor;
    vec2 position;
    vec2 characterPosition;
    vec2 localPosition;
    vec2 uv;
    vec2 uvMin;
    vec2 uvMax;
    vec2 uvCenter;
    bool isShadow;
    bool doTextureLookup;
    bool shouldScale;
};

TextData textData;

float fastTime;
float medTime;
float slowTime;

void initTimeValues() {
    fastTime = GameTime * 500.0;
    medTime = GameTime * 1200.0;
    slowTime = GameTime * 300.0;
}

bool uvBoundsCheck(vec2 uv, vec2 uvMin, vec2 uvMax) {
    if(isnan(uv.x) || isnan(uv.y)) return true;
    const float error = 0.0001;
    return uv.x < textData.uvMin.x + error || uv.y < textData.uvMin.y + error || uv.x > textData.uvMax.x - error || uv.y > textData.uvMax.y - error;
}

vec3 textSdf() {
    vec3 value = vec3(0.0, 0.0, 1.0);

    vec2 texelSize = 1.0 / vec2(256.0);
    for(int x = -1; x <= 1; x++) {
        for(int y = -1; y <= 1; y++) {
            vec2 uv = textData.uv + vec2(x, y) * texelSize;
            if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;

            vec4 s = texture(Sampler0, uv);
            if(s.a >= 0.1) {
                vec3 v = vec3(fract(uv * 256.0), 0.0);

                if(x == 0) v.x = 0.0;
                if(y == 0) v.y = 0.0;
                if(x > 0) v.x = 1.0-v.x;
                if(y > 0) v.y = 1.0-v.y;

                v.z = length(v.xy);

                if(v.z < value.z) value = v;
            }
        }
    }
    return value;
}

void override_text_color(vec4 color) {
    textData.color = color;
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void override_text_color(vec3 color) {
    textData.color.rgb = color;
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void override_shadow_color(vec4 color) {
    if(textData.isShadow) {
        textData.color = color;
        textData.topColor.rgb = color.rgb;
        textData.topColor.a *= color.a;
        textData.backColor.rgb = color.rgb;
        textData.backColor.a *= color.a;
    }
}

void override_shadow_color(vec3 color) {
    override_shadow_color(vec4(color, 1.0));
}

void remove_text_shadow() {
    if(textData.isShadow) textData.color.a = 0.0;
}

void apply_vertical_shadow() {
    if(textData.isShadow) {
        textData.uv.x += 1.0 / 256.0;
        textData.shouldScale = true;
    }
}

void apply_waving_movement(float speed, float frequency) {
    textData.uv.y += sin(textData.characterPosition.x * 0.1 * frequency - GameTime * 7500.0 * speed) / 256.0;
    textData.shouldScale = true;
}

void apply_waving_movement(float speed) {
    apply_waving_movement(speed, 1.0);
}

void apply_waving_movement() {
    apply_waving_movement(1.0, 1.0);
}

void apply_shaking_movement() {
    float noiseX = noise(textData.characterPosition.x + textData.characterPosition.y + GameTime * 32000.0) - 0.5;
    float noiseY = noise(textData.characterPosition.x - textData.characterPosition.y + GameTime * 32000.0) - 0.5;
    textData.shouldScale = true;

    textData.uv += vec2(noiseX, noiseY) / 256.0;
}

void apply_iterating_movement(float speed, float space) {
    float x = mod(textData.characterPosition.x * 0.4 - GameTime * 18000.0 * speed, (5.0 * space) * TAU);
    if(x > TAU) x = TAU;
    textData.uv.y += (-cos(x) * 0.5 + 0.5) / 256.0;
    textData.shouldScale = true;
}

void apply_iterating_movement() {
    apply_iterating_movement(1.0, 1.0);
}

void apply_flipping_movement(float speed, float space) {
    float t = mod((textData.characterPosition.x * 0.4 - GameTime  * 18000.0 * speed) / TAU, 5.0 * space);
    textData.uv.x = textData.uvCenter.x + (textData.uv.x - textData.uvCenter.x) / (cos(TAU * min(t, 1.0)));
    textData.uv.y = textData.uvCenter.y + (textData.uv.y - textData.uvCenter.y) / (1.0 + 0.1 * sin(TAU * min(t, 1.0)));
    textData.shouldScale = true;
}

void apply_flipping_movement() {
    apply_flipping_movement(1.0, 1.0);
}

void apply_skewing_movement(float speed) {
    float t = GameTime * 1600.0 * speed;

    textData.uv.x = mix(textData.uv.x, textData.uv.x + sin(TAU * t * 0.5) / 256.0, 1.0 - textData.localPosition.y);
    textData.uv.y = mix(textData.uv.y, textData.uvMax.y, -(0.3 + 0.5 * cos(TAU * t)));
    textData.shouldScale = true;
}

void apply_skewing_movement() { 
    apply_skewing_movement(1.0);
}

void apply_growing_movement(float speed) {
    vec2 offset = vec2(0.0, 5.0 / 256.0);
    textData.uv = (textData.uv - textData.uvCenter - offset) * (sin(GameTime * 12800.0 * speed) * 0.15 + 0.85) + textData.uvCenter + offset;
    textData.shouldScale = true;
}

void apply_growing_movement() {
    apply_growing_movement(1.0);
}

void apply_outline(vec3 color) {
    textData.shouldScale = true;

    if(textData.isShadow) {
        color *= 0.25;
        textData.color.rgb = color;
    } 

    vec2 texelSize = 1.0 / vec2(256.0);
    bool outline = false;

    for(int x = -1; x <= 1; x++) {
        for(int y = -1; y <= 1; y++) {
            if(x == 0 && y == 0) continue;

            vec2 uv = textData.uv + vec2(x, y) * texelSize;
            if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;

            vec4 s = texture(Sampler0, uv);
            if(s.a >= 0.1) { textData.backColor = vec4(color, 1.0); return; }
        }
    }
}

void apply_thin_outline(vec3 color) {
    textData.shouldScale = true;

    if(textData.isShadow) {
        color *= 0.25;
        textData.color.rgb = color;
    } 
    
    vec2 texelSize = 0.5 / vec2(256.0);
    bool outline = false;

    for(int x = -1; x <= 1; x++) {
        for(int y = -1; y <= 1; y++) {
            if(x == 0 && y == 0) continue;

            vec2 uv = textData.uv + vec2(x, y) * texelSize;
            if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;

            vec4 s = texture(Sampler0, uv);
            if(s.a >= 0.1) { textData.backColor = vec4(color, 1.0); return; }
        }
    }
}



float pink_fractal_rand(vec2 n) { 
    return fract(sin(dot(n, vec2(12.9898, 4.1414))) * 43758.5453);
}

float pink_fractal_noise(vec2 p){
    vec2 ip = floor(p);
    vec2 u = fract(p);
    u = u*u*(3.0-2.0*u);

    float res = mix(
        mix(pink_fractal_rand(ip),pink_fractal_rand(ip+vec2(1.0,0.0)),u.x),
        mix(pink_fractal_rand(ip+vec2(0.0,1.0)),pink_fractal_rand(ip+vec2(1.0,1.0)),u.x),u.y);
    return res*res;
}

float pink_fractal_fbm( vec2 p ) {

    return 0.516129 * pink_fractal_noise( p + GameTime * 1200.0);
}

// Main function to apply the animated pink fractal effect
void apply_pink_fractal() {
    #ifdef FSH
        vec2 uv = vec2(gl_FragCoord.xy) / 100.0;
        float shade = pink_fractal_fbm(uv);
        textData.color.rgb = mix(vec3(0.21,-1,0.21), vec3(3.25, 3.136,1.75), shade);
        if(textData.isShadow) {
            textData.color.rgb *= 0.25;
        }
    #endif
}

float fast_hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float fast_noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    float a = fast_hash(i);
    float b = fast_hash(i + vec2(1.0, 0.0));
    float c = fast_hash(i + vec2(0.0, 1.0));
    float d = fast_hash(i + vec2(1.0, 1.0));
    
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fast_fbm(vec2 p) {
    float value = 0.0;
    value += 0.5 * fast_noise(p);
    value += 0.25 * fast_noise(p * 2.0);
    return value;
}

void apply_rainbow_fractal() {
    #ifdef FSH
        vec2 uv = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
        float fractalShade = fast_fbm(uv + medTime);
        
        vec2 smoothCoord = vec2(gl_FragCoord.xy);
        float baseHue = 0.003 * (smoothCoord.x + smoothCoord.y) - slowTime;
        
        float hue = mod(baseHue + fractalShade * 1.0, 1.0); // Full fractal influence restored

        textData.color.rgb = hsvToRgb(vec3(hue, 0.7, 1.0));

        if (textData.isShadow) {
            textData.color.rgb *= 0.25;
        }
    #endif
}

void apply_pastel_rainbow_fractal() {
    #ifdef FSH
        vec2 uv = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
        float fractalShade = fast_fbm(uv + medTime);
        
        vec2 smoothCoord = vec2(gl_FragCoord.xy);
        float baseHue = 0.003 * (smoothCoord.x + smoothCoord.y) - slowTime;
        
        float hue = mod(baseHue + fractalShade * 1.0, 1.0);
        textData.color.rgb = hsvToRgb(vec3(hue, 0.38, 0.95));
        if (textData.isShadow) {
            textData.color.rgb *= 0.25;
        }
    #endif
}

float marble_fbm(vec2 p){
    float s = 0.0;
    s += 0.5   * noise(p); p *= 2.02;
    s += 0.25  * noise(p);
    return s;
}

void apply_marble_turbulence(vec3 colorA, vec3 colorB) {
    #ifdef FSH
        
        vec2 p = gl_FragCoord.xy / 64.0;
        
        vec2 tscroll = vec2(GameTime * 1200.0, GameTime * 800.0);
        float m = marble_fbm(p + tscroll);

        float bands = 0.5 + 0.5 * sin(12.0 * m);
        vec3 col = mix(colorA, colorB, bands);

        if(textData.isShadow) col *= 0.25;
        textData.color.rgb = col;
        textData.shouldScale = true;
    #endif
}

void apply_gradient(vec3 color1, vec3 color2) {
    textData.color.rgb = mix(color1, color2, (textData.uv.y - textData.uvMin.y) / (textData.uvMax.y - textData.uvMin.y));
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_rainbow() {
    textData.color.rgb = hsvToRgb(vec3(0.005 * (textData.position.x + textData.position.y) - GameTime * 300.0, 0.7, 1.0));
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_pastel_rainbow() {
    vec3 hsvColor = vec3(0.005 * (textData.position.x + textData.position.y) - slowTime, 0.3, 0.95);
    textData.color.rgb = hsvToRgb(hsvColor);
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

float camo_hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float camo_noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    float a = camo_hash(i);
    float b = camo_hash(i + vec2(1.0, 0.0));
    float c = camo_hash(i + vec2(0.0, 1.0));
    float d = camo_hash(i + vec2(1.0, 1.0));
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}

float camo_fbm(vec2 p) {
    float total = 0.0;
    float amplitude = 0.6;
    for (int i = 0; i < 4; i++) {
        total += camo_noise(p) * amplitude;
        p *= 1.8;
        amplitude *= 0.5;
    }
    return total;
}

void apply_camo(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed) {
    #ifdef FSH
        vec2 uv = vec2(gl_FragCoord.xy) / 50.0;
        float time = GameTime * 400.0 * speed;
        
        // Create chunky camo blobs
        float n1 = camo_fbm(uv * 2.0 + vec2(time * 0.08, 0.0));
        float n2 = camo_fbm(uv * 1.5 + vec2(100.0, time * 0.06));
        
        // Combine and create sharp transitions
        float pattern = n1 * 0.6 + n2 * 0.4;
        
        // Stretch the pattern to use full range (noise tends to cluster 0.3-0.7)
        pattern = clamp((pattern - 0.3) * 2.0, 0.0, 1.0);
        
        // Even color bands - 25% each
        vec3 color;
        if (pattern < 0.25) {
            color = color4;  // darkest
        } else if (pattern < 0.5) {
            color = color3;
        } else if (pattern < 0.75) {
            color = color2;
        } else {
            color = color1;  // brightest
        }
        
        textData.color.rgb = color;
        
        if (textData.isShadow) {
            textData.color.rgb *= 0.25;
        }
    #endif
}

void apply_animated_gradient(vec3 color1, vec3 color2) {
    float t = 0.05 * (textData.position.x + textData.position.y) - GameTime * 8000.0;
    float smoothT = (sin(t) + 1.0) * 0.5; // This will oscillate smoothly between 0 and 1
    textData.color.rgb = mix(color1, color2, smoothT);
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_character_cycle(vec3 startRGB, vec3 endRGB, float speed, float frequency) {
    float timeOffset = fastTime * speed;
    float positionOffset = textData.characterPosition.x * frequency;
    float wave = sin(positionOffset - timeOffset) * 0.5 + 0.5;

    textData.color.rgb = mix(startRGB, endRGB, wave);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
}

void apply_character_3(vec3 color1, vec3 color2, vec3 color3, float speed, float frequency) {
    float timeOffset = fastTime * speed;
    float positionOffset = textData.characterPosition.x * frequency;
    float cycle = mod(positionOffset - timeOffset, 3.0);

    vec3 resultColor;
    if (cycle < 1.0) {
        resultColor = mix(color1, color2, cycle);
    } else if (cycle < 2.0) {
        resultColor = mix(color2, color3, cycle - 1.0);
    } else {
        resultColor = mix(color3, color1, cycle - 2.0);
    }

    textData.color.rgb = resultColor;

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
}

void apply_character_cycle_7(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7, float speed, float frequency) {
    float timeOffset = fastTime * speed;
    float positionOffset = textData.characterPosition.x * frequency;
    float cycle = mod(positionOffset - timeOffset, 7.0);

    vec3 resultColor;
    if (cycle < 1.0) {
        resultColor = mix(color1, color2, cycle);
    } else if (cycle < 2.0) {
        resultColor = mix(color2, color3, cycle - 1.0);
    } else if (cycle < 3.0) {
        resultColor = mix(color3, color4, cycle - 2.0);
    } else if (cycle < 4.0) {
        resultColor = mix(color4, color5, cycle - 3.0);
    } else if (cycle < 5.0) {
        resultColor = mix(color5, color6, cycle - 4.0);
    } else if (cycle < 6.0) {
        resultColor = mix(color6, color7, cycle - 5.0);
    } else {
        resultColor = mix(color7, color1, cycle - 6.0);
    }

    textData.color.rgb = resultColor;

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
}

void apply_animated_gradient_3(vec3 color1, vec3 color2, vec3 color3) {
    float t = 0.05 * (textData.position.x + textData.position.y) - GameTime * 5000.0;
    float smoothT = fract(t / (2.0 * 3.14159)) * 3.0; // 0 to 3 range
    
    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else {
        resultColor = mix(color3, color1, smoothT - 2.0);
    }
    
    textData.color.rgb = resultColor;
    if(textData.isShadow) textData.color.rgb *= 0.25;
}


void apply_animated_gradient_7(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7) {
    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 500.0;
    float smoothT = fract(t) * 7.0; // 0 to 7 range
    
    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        resultColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        resultColor = mix(color4, color5, smoothT - 3.0);
    } else if (smoothT < 5.0) {
        resultColor = mix(color5, color6, smoothT - 4.0);
    } else if (smoothT < 6.0) {
        resultColor = mix(color6, color7, smoothT - 5.0);
    } else {
        resultColor = mix(color7, color1, smoothT - 6.0);
    }
    
    float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
    resultColor = mix(resultColor, vec3(1.0), wave * 0.15);
    
    textData.color.rgb = resultColor;
    if(textData.isShadow) textData.color.rgb *= 0.25;
}


void apply_animated_gradient_7_smoother(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7) {
    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 500.0;
    float smoothT = fract(t) * 12.0; // 0 to 12 range
    
    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        resultColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        resultColor = mix(color4, color5, smoothT - 3.0);
    } else if (smoothT < 5.0) {
        resultColor = mix(color5, color6, smoothT - 4.0);
    } else if (smoothT < 6.0) {
        resultColor = mix(color6, color7, smoothT - 5.0);
    } else if (smoothT < 7.0) {
        resultColor = mix(color7, color6, smoothT - 6.0);
    } else if (smoothT < 8.0) {
        resultColor = mix(color6, color5, smoothT - 7.0);
    } else if (smoothT < 9.0) {
        resultColor = mix(color5, color4, smoothT - 8.0);
    } else if (smoothT < 10.0) {
        resultColor = mix(color4, color3, smoothT - 9.0);
    } else if (smoothT < 11.0) {
        resultColor = mix(color3, color2, smoothT - 10.0);
    } else {
        resultColor = mix(color2, color1, smoothT - 11.0);
    }
    
    float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
    resultColor = mix(resultColor, vec3(1.0), wave * 0.15);
    
    textData.color.rgb = resultColor;
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_breathing_colors(vec3 color1, vec3 color2, float speed) {
    float t = sin(GameTime * 1200.0 * speed * PI) * 0.5 + 0.5;
    vec3 col = mix(color1, color2, t);
    if(textData.isShadow) col *= 0.25;
    textData.color.rgb = col;
    textData.shouldScale = true;
}

void apply_breathing_colors(vec3 color1, vec3 color2) {
    apply_breathing_colors(color1, color2, 1.0);
}

void apply_shimmer(float speed, float intensity) {
    if(textData.isShadow) return;
    float f = textData.localPosition.x + textData.localPosition.y - GameTime * 6400.0 * speed;
    
    if(mod(f, 5) < 0.75) textData.topColor = vec4(1.0, 1.0, 1.0, intensity);
}

void apply_shimmer(){
    apply_shimmer(1.0, 0.5);
}

void apply_shimmer_with_color(vec3 shimmerColor, float speed, float intensity) {
    if(textData.isShadow) return;
    float f = textData.localPosition.x + textData.localPosition.y - GameTime * 6400.0 * speed;

    if(mod(f, 5) < 0.75) textData.topColor = vec4(shimmerColor, intensity);
    textData.shouldScale = true;
}

void apply_glitch(float intensity, float speed) {
    textData.shouldScale = true;
    float time = floor(GameTime * speed * 6000.0);
    float glitchLine = floor(textData.uv.y * 256.0);
    if (random(vec2(glitchLine, time)) < intensity) {
        float offset = (random(vec2(glitchLine, time + 1.0)) * 2.0 - 1.0) * 3.0 / 256.0;
        textData.uv.x += offset;
        textData.uv = clamp(textData.uv, textData.uvMin, textData.uvMax);
    }
    textData.shouldScale = true;
}

void apply_jumping(float speed) {
    float t = GameTime * 3000.0 * speed;
    float charOffset = textData.characterPosition.x * 0.08;
    
    // Hop = fast up, slow fall (like a bounce)
    float hop = -abs(sin(t + charOffset));
    textData.uv.y += hop * 1.2 / 256.0;
    
    // Slight squish on landing
    float squish = abs(cos(t + charOffset)) * 0.3;
    textData.uv.x += sin(charOffset) * squish * 0.4 / 256.0;
    
    textData.shouldScale = false;
}

void apply_chromatic_abberation() {
    textData.shouldScale = true;
    float noiseX = noise(GameTime * 12000.0) - 0.5;
    float noiseY = noise(GameTime * 12000.0 + 19732.134) - 0.5;
    vec2 offset = vec2(0.5 / 256, 0.0) + vec2(0.5, 1.0) * vec2(noiseX, noiseY) / 256;

    vec2 uv = textData.uv + offset;
    vec4 s1 = texture(Sampler0, uv);
    s1.rgb *= s1.a;
    if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) s1 = vec4(0.0);

    uv = textData.uv - offset;
    vec4 s2 = texture(Sampler0, uv);
    s2.rgb *= s2.a;
    if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) s2 = vec4(0.0);

    textData.backColor = (s1 * vec4(1.0, 0.25, 0.0, 1.0)) + (s2 * vec4(0.0, 0.75, 1.0, 1.0));
    textData.backColor.rgb *= textData.color.rgb;
}

void apply_metalic(vec3 lightColor, vec3 darkColor) {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));
    
    if(y > 3) textData.color.rgb = darkColor;
    if(y == 3) textData.color.rgb = lightColor + 0.25;
    if(y < 3) textData.color.rgb = lightColor;

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_metalic(vec3 color) {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));
    
    if(y > 3) textData.color.rgb = color * 0.7;
    if(y == 3) textData.color.rgb = color + 0.25;
    if(y < 3) textData.color.rgb = color;

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_fire() {
    textData.shouldScale = true;
    if(textData.isShadow) return;

    float h = fract(textData.uv.y * 256.0);
    vec2 uv = textData.uv + vec2(0.0, 1.0 / 256);
    if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) return;
    vec4 s = texture(Sampler0, uv);
    if(s.a > 0.1) {
        float f = noise(textData.localPosition * 32.0 + vec2(0.0, GameTime * 6400.0)) * 0.5 + 0.5;
        f -= (1.0 - sqrt(h)) * 0.8;

        if(f > 0.5)
        textData.backColor = vec4(mix(vec3(1.0, 0.2, 0.2), vec3(1.0, 0.7, 0.3), (f - 0.5) / 0.5), 1.0);
    }
}

void apply_fade(float speed) {
    textData.color.a = mix(textData.color.a, 0.0, sin(GameTime * 1200 * speed * PI) * 0.5 + 0.5);
}

void apply_fade() {
    apply_fade(1.0);
}

void apply_fade(vec3 color, float speed) {
    if(textData.isShadow) color *= 0.25;

    textData.color.rgb = mix(textData.color.rgb, color, sin(GameTime * 1200 * speed * PI) * 0.5 + 0.5);
}

void apply_fade(vec3 color) {
    apply_fade(color, 1.0);
}

void apply_blinking(float speed){
    if(sin(GameTime * 3200 * speed * PI) < 0.0) { textData.color.a = 0.0; textData.backColor.a = 0.0; textData.topColor.a = 0.0; }
}

void apply_blinking() {
    apply_blinking(1.0);
}

void apply_glowing() {
    if(textData.isShadow) textData.color = vec4(0.0);
    vec3 d = textSdf();
    textData.backColor = vec4(1.0, 1.0, 1.0, (1.0 - d.z) * (1.0 - d.z));
}

void apply_lesbian_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  3) textData.color.rgb = vec3(0.839, 0.161, 0.000);
    if(y == 3) textData.color.rgb = vec3(1.000, 0.608, 0.333);
    if(y == 4) textData.color.rgb = vec3(1.000, 1.000, 1.000);
    if(y == 5) textData.color.rgb = vec3(0.831, 0.384, 0.647);
    if(y >  5) textData.color.rgb = vec3(0.647, 0.000, 0.384);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_mlm_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  3) textData.color.rgb = vec3(0.000, 0.584, 0.525);
    if(y == 3) textData.color.rgb = vec3(0.412, 0.941, 0.686);
    if(y == 4) textData.color.rgb = vec3(1.000, 1.000, 1.000);
    if(y == 5) textData.color.rgb = vec3(0.510, 0.698, 1.000);
    if(y >  5) textData.color.rgb = vec3(0.271, 0.153, 0.627);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_bisexual_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  4) textData.color.rgb = vec3(0.843, 0.000, 0.443);
    if(y == 4) textData.color.rgb = vec3(0.612, 0.306, 0.592);
    if(y >  4) textData.color.rgb = vec3(0.000, 0.208, 0.663);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_transgender_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  3) textData.color.rgb = vec3(0.357, 0.812, 0.980);
    if(y == 3) textData.color.rgb = vec3(0.961, 0.671, 0.725);
    if(y == 4) textData.color.rgb = vec3(1.000, 1.000, 1.000);
    if(y == 5) textData.color.rgb = vec3(0.961, 0.671, 0.725);
    if(y >  5) textData.color.rgb = vec3(0.357, 0.812, 0.980);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  2) textData.color.rgb = vec3(1.000, 0.012, 0.012);
    if(y == 2) textData.color.rgb = vec3(1.000, 0.549, 0.000);
    if(y == 3) textData.color.rgb = vec3(1.000, 0.929, 0.000);
    if(y == 4) textData.color.rgb = vec3(0.000, 0.502, 0.149);
    if(y == 5) textData.color.rgb = vec3(0.000, 0.302, 1.000);
    if(y >  5) textData.color.rgb = vec3(0.459, 0.027, 0.529);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_pansexual_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  3) textData.color.rgb = vec3(1.000, 0.129, 0.549);
    if(y == 3) textData.color.rgb = vec3(1.000, 0.847, 0.000);
    if(y == 4) textData.color.rgb = vec3(1.000, 0.847, 0.000);
    if(y >  4) textData.color.rgb = vec3(0.129, 0.694, 1.000);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_asexual_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  3) textData.color.rgb = vec3(0.100, 0.100, 0.100);
    if(y == 3) textData.color.rgb = vec3(0.639, 0.639, 0.639);
    if(y == 4) textData.color.rgb = vec3(1.000, 1.000, 1.000);
    if(y >  4) textData.color.rgb = vec3(0.502, 0.000, 0.502);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_aromantic_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  3) textData.color.rgb = vec3(0.047, 0.655, 0.294);
    if(y == 3) textData.color.rgb = vec3(0.584, 0.796, 0.451);
    if(y == 4) textData.color.rgb = vec3(1.000, 1.000, 1.000);
    if(y == 5) textData.color.rgb = vec3(0.639, 0.639, 0.639);
    if(y >  5) textData.color.rgb = vec3(0.100, 0.100, 0.100);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_non_binary_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  3) textData.color.rgb = vec3(1.000, 0.957, 0.173);
    if(y == 3) textData.color.rgb = vec3(1.000, 1.000, 1.000);
    if(y == 4) textData.color.rgb = vec3(0.616, 0.349, 0.824);
    if(y >  4) textData.color.rgb = vec3(0.100, 0.100, 0.100);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_vertical_animated_gradient(vec3 color1, vec3 color2) {
    float t = 0.2 * textData.position.y - GameTime * 2000.0;
    float smoothT = (sin(t) + 1.0) * 0.5;
    textData.color.rgb = mix(color1, color2, smoothT);
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_vertical_animated_gradient_3(vec3 color1, vec3 color2, vec3 color3) {
    float t = 0.2 * textData.position.y - GameTime * 1500.0;
    float smoothT = fract(t / (2.0 * 3.14159)) * 3.0;
    
    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else {
        resultColor = mix(color3, color1, smoothT - 2.0);
    }
    
    textData.color.rgb = resultColor;
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

// Lightweight effect lookup used by the vertex shader.
// Every active FadePack text effect currently requests scaled bounds, so the
// vertex stage only needs to identify whether the marker color maps to an
// effect. Executing the full effect body here duplicated gradient/noise/UV
// work that is only meaningful in the fragment shader.
#define TEXT_EFFECT(r, g, b) return true; case ((uint(r/4) << 16) | (uint(g/4) << 8) | (uint(b/4))): if(false)

bool hasTextEffect() {
    uint vertexColorId = colorId(floor(round(textData.color.rgb * 255.0) / 4.0) / 255.0);
    if(textData.isShadow) { vertexColorId = colorId(textData.color.rgb); }
    switch(vertexColorId >> 8) {
        case 0xFFFFFFFFu:

    #include <text_effects_config.glsl>

        return true;
    }
    return false;
}

#undef TEXT_EFFECT
#define TEXT_EFFECT(r, g, b) return true; case ((uint(r/4) << 16) | (uint(g/4) << 8) | (uint(b/4))):

bool applyTextEffects() { 
    uint vertexColorId = colorId(floor(round(textData.color.rgb * 255.0) / 4.0) / 255.0); 
    if(textData.isShadow) { vertexColorId = colorId(textData.color.rgb);} 
    switch(vertexColorId >> 8) { 
        case 0xFFFFFFFFu:

    #include <text_effects_config.glsl>
    
        return true; 
    } 
    return false;
}

#define SPHEYA_PACK_9

#ifdef FSH
layout(location = 6) in vec4 vctfx_screenPos;
layout(location = 7) flat in float vctfx_applyTextEffect;
layout(location = 8) flat in float vctfx_isShadow;
layout(location = 9) flat in float vctfx_changedScale;

layout(location = 10) in vec3 vctfx_ipos1;
layout(location = 11) in vec3 vctfx_ipos2;
layout(location = 12) in vec3 vctfx_ipos3;
layout(location = 13) in vec3 vctfx_ipos4;

layout(location = 14) in vec3 vctfx_uvpos1;
layout(location = 15) in vec3 vctfx_uvpos2;
layout(location = 16) in vec3 vctfx_uvpos3;
layout(location = 17) in vec3 vctfx_uvpos4;

bool applySpheyaPack9() {
    if(vctfx_applyTextEffect < 0.5) return false;

    initTimeValues();

    textData.isShadow = vctfx_isShadow > 0.5;
    textData.backColor = vec4(0.0);
    textData.topColor = vec4(0.0);
    textData.doTextureLookup = true;
    textData.color = baseColor;
    
    vec2 ip1 = vctfx_ipos1.xy / vctfx_ipos1.z;
    vec2 ip2 = vctfx_ipos2.xy / vctfx_ipos2.z;
    vec2 ip3 = vctfx_ipos3.xy / vctfx_ipos3.z;
    vec2 ip4 = vctfx_ipos4.xy / vctfx_ipos4.z;
    vec2 innerMin = min(ip1.xy,min(ip2.xy,min(ip3.xy,ip4.xy)));
    vec2 innerMax = max(ip1.xy,max(ip2.xy,max(ip3.xy,ip4.xy)));
    vec2 innerSize = innerMax - innerMin;
    
    vec2 uvp1 = vctfx_uvpos1.xy / vctfx_uvpos1.z;
    vec2 uvp2 = vctfx_uvpos2.xy / vctfx_uvpos2.z;
    vec2 uvp3 = vctfx_uvpos3.xy / vctfx_uvpos3.z;
    vec2 uvp4 = vctfx_uvpos4.xy / vctfx_uvpos4.z;
    vec2 uvMin = min(uvp1.xy,min(uvp2.xy,min(uvp3.xy, uvp4.xy)));
    vec2 uvMax = max(uvp1.xy,max(uvp2.xy,max(uvp3.xy, uvp4.xy)));
    vec2 uvSize = uvMax - uvMin;
    textData.uvMin = uvMin;
    textData.uvMax = uvMax;
    textData.uvCenter = uvMin + 0.25 * uvSize;
    textData.localPosition = ((vctfx_screenPos.xy - innerMin) / innerSize);
    textData.localPosition.y = 1.0 - textData.localPosition.y;
    textData.uv = textData.localPosition * uvSize + uvMin;
    if(vctfx_changedScale < 0.5) {
        textData.uv = texCoord0;
    }
    textData.position = vctfx_screenPos.xy * uvSize * 256.0 / innerSize;
    textData.characterPosition = 0.5 * (innerMin + innerMax) * uvSize * 256.0 / innerSize;
    if(textData.isShadow) { 
        textData.characterPosition += vec2(-1.0, 1.0);
        textData.position += vec2(-1.0, 1.0);
    }
    applyTextEffects();
    if(uvBoundsCheck(textData.uv, uvMin, uvMax)) textData.doTextureLookup = false;
    
    vec4 textureSample = texture(Sampler0, textData.uv);

#ifdef RENDERTYPE_TEXT_INTENSITY
    textureSample = textureSample.rrrr;
    textureSample = vec4(0.0);
#endif

    if(!textData.doTextureLookup) textureSample = vec4(0.0);
    textData.topColor.a *= textureSample.a;

    vec4 effectColor = mix(vec4(textData.backColor.rgb, textData.backColor.a * textData.color.a), textureSample * textData.color, textureSample.a);
    effectColor.rgb = mix(effectColor.rgb, textData.topColor.rgb, textData.topColor.a);
    effectColor *= lightColor * ColorModulator;

    if (effectColor.a < 0.1) {
        discard;
    }

#ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, effectColor.a);
#else
#ifdef OIT_ACCUMULATE
    effectColor = sampleColorForAccumulation(effectColor);
#endif
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#ifdef OIT_ACCUMULATE
    vec4 effectFogColor = vec4(FogColor.rgb * effectColor.a, FogColor.a);
#else
    vec4 effectFogColor = FogColor;
#endif
    fragColor = apply_fog(
        effectColor,
        sphericalVertexDistance,
        cylindricalVertexDistance,
        FogEnvironmentalStart,
        FogEnvironmentalEnd,
        FogRenderDistanceStart,
        FogRenderDistanceEnd,
        effectFogColor
    );
#else
    fragColor = effectColor;
#endif
#endif
    return true;
}

#endif

#ifdef VSH
layout(location = 6) out vec4 vctfx_screenPos;
layout(location = 7) flat out float vctfx_applyTextEffect;
layout(location = 8) flat out float vctfx_isShadow;
layout(location = 9) flat out float vctfx_changedScale;

layout(location = 10) out vec3 vctfx_ipos1;
layout(location = 11) out vec3 vctfx_ipos2;
layout(location = 12) out vec3 vctfx_ipos3;
layout(location = 13) out vec3 vctfx_ipos4;

layout(location = 14) out vec3 vctfx_uvpos1;
layout(location = 15) out vec3 vctfx_uvpos2;
layout(location = 16) out vec3 vctfx_uvpos3;
layout(location = 17) out vec3 vctfx_uvpos4;

bool applySpheyaPack9() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vctfx_isShadow = fract(Position.z) < 0.01 ? 1.0 : 0.0;
    vctfx_applyTextEffect = 1.0;
    vctfx_changedScale = 0.0;

    textData.isShadow = vctfx_isShadow > 0.5;
    textData.color = Color;
    textData.shouldScale = false;

    if(!hasTextEffect()) {
        vctfx_isShadow = 0.0;

#ifdef IS_1_21_6
        if (textData.isShadow)
        {
#else
        if(Position.z == 0.0 && textData.isShadow) {
#endif
            textData.isShadow = false;
            if(hasTextEffect()) {
                vctfx_isShadow = 0.0;
            }else {
                vctfx_applyTextEffect = 0.0;
                return false;
            }
        }else{
            vctfx_applyTextEffect = 0.0;
            return false;
        }
    }

    // All currently configured effects need the expanded quad. Avoid running
    // their full effect bodies in VSH just to set this flag.
    textData.shouldScale = true;

    vec2 corner = vec2[](vec2(-1.0, +1.0), vec2(-1.0, -1.0), vec2(+1.0, -1.0), vec2(+1.0, +1.0))[gl_VertexIndex % 4];
    if(textureSize(Sampler0, 0) != ivec2(256, 256)) {
        vctfx_applyTextEffect = 0.0;
        return false;
    }

    vctfx_uvpos1 = vctfx_uvpos2 = vctfx_uvpos3 = vctfx_uvpos4 = vctfx_ipos1 = vctfx_ipos2 = vctfx_ipos3 = vctfx_ipos4 = vec3(0.0);
    switch (gl_VertexIndex % 4) {
        case 0: vctfx_ipos1 = vec3(gl_Position.xy, 1.0); vctfx_uvpos1 = vec3(UV0.xy, 1.0); break;
        case 1: vctfx_ipos2 = vec3(gl_Position.xy, 1.0); vctfx_uvpos2 = vec3(UV0.xy, 1.0); break;
        case 2: vctfx_ipos3 = vec3(gl_Position.xy, 1.0); vctfx_uvpos3 = vec3(UV0.xy, 1.0); break;
        case 3: vctfx_ipos4 = vec3(gl_Position.xy, 1.0); vctfx_uvpos4 = vec3(UV0.xy, 1.0); break;
    } 

    if(textData.shouldScale) {
        gl_Position.xy += corner * 0.2;
        vctfx_changedScale = 1.0;
    }

    vctfx_screenPos = gl_Position;
#ifdef IS_1_21_6
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
#endif
#else
    vertexDistance = length((ModelViewMat * vec4(Position, 1.0)).xyz);
#endif
    vertexColor = baseColor * lightColor;
    texCoord0 = UV0;
    return true;
}

#endif

#endif
