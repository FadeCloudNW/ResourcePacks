#version 330
#extension GL_ARB_separate_shader_objects : require
#define VSH
#define RENDERTYPE_TEXT
#define IS_1_21_6

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:globals.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

uniform sampler2D Sampler0;
layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;
layout(location = 4) out vec4 baseColor;
layout(location = 5) out vec4 lightColor;

#include <spheya_packs_impl.glsl>

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    baseColor = Color;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    lightColor = sample_lightmap(Sampler2, UV2);
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = baseColor * lightColor;
#else
    lightColor = vec4(1.0);
    vertexColor = baseColor;
#endif
    texCoord0 = UV0;
    if (applySpheyaPacks()) return;
}
