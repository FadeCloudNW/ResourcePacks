#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

#define V1 32
#define V2 50

uniform sampler2D Sampler0;
#ifdef DISSOLVE
uniform sampler2D DissolveMaskSampler;
#endif
#ifdef GLINT
uniform sampler2D GlintSampler;
#endif

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
layout(location = 2) in vec4 vertexPerFaceColorBack;
layout(location = 3) in vec4 vertexPerFaceColorFront;
#else
layout(location = 2) in vec4 vertexColor;
#endif
#ifndef EMISSIVE
layout(location = 4) in vec4 lightMapColor;
#endif
#ifndef NO_OVERLAY
layout(location = 5) in vec4 overlayColor;
#endif
layout(location = 6) in vec2 texCoord0;
#ifdef GLINT
layout(location = 7) in vec2 texCoordGlint;
#endif
layout(location = 8) flat in vec4 tint;
layout(location = 9) flat in vec3 vNormal;
layout(location = 10) flat in vec4 texel;
layout(location = 11) flat in vec4 fadeWhiteLight;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 fadeFinalColor(vec4 color) {
#ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
#endif
#ifndef EMISSIVE
    color *= lightMapColor;
#endif
#ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);
    color.rgb += glintColor.rgb * glintColor.rgb;
#endif
#ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
#else
    vec4 fogColor = FogColor;
#endif
    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance,
        FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}

void fadeEmitCustom(vec4 color) {
#ifdef OIT_ADDITIVE
    color.a = min(0.99, color.a);
#endif
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) discard;
#endif
#ifdef GLINT
    color.a = max(color.a, GlintAlpha);
#endif
#ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
#else
#ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
#else
    vec4 fogColor = FogColor;
#endif
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance,
        FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
#endif
}

void main() {
#ifdef PER_FACE_LIGHTING
    vec4 faceVertexColor = gl_FrontFacing ? vertexPerFaceColorFront : vertexPerFaceColorBack;
#else
    vec4 faceVertexColor = vertexColor;
#endif

    ivec2 atlasSize = textureSize(Sampler0, 0);
    bool fadeArmor = atlasSize == ivec2(3584, 64) && tint != vec4(0.0) && texelFetch(Sampler0, ivec2(0, 1), 0) == vec4(1.0);

    if (fadeArmor) {
        float armorAmount = atlasSize.x / (V1 * 4.0);
        float maxFrames = atlasSize.y / (V1 * 2.0);
        vec2 coords = texCoord0;
        coords.x /= armorAmount;
        coords.y /= maxFrames;

        vec4 textureProperties = vec4(0.0);
        vec4 customColor = vec4(0.0);
        float h_offset = 1.0 / armorAmount;
        vec2 nextFrame = coords;
        float interpolClock = 0.0;
        vec4 vtc = faceVertexColor;

        for (int i = 1; i < int(armorAmount + 1.0); i++) {
            customColor = texelFetch(Sampler0, ivec2(V1 * 4 * i, 0), 0);
            if (tint == customColor) {
                coords.x += h_offset * i;
                vec4 animInfo = texelFetch(Sampler0, ivec2(V1 * 4 * i + 1, 0), 0);
                animInfo.rgb *= animInfo.a * 255.0;
                textureProperties = texelFetch(Sampler0, ivec2(V1 * 4 * i + 2, 0), 0);
                textureProperties.rgb *= textureProperties.a * 255.0;
                if (animInfo != vec4(0.0)) {
                    float timer = floor(mod(GameTime * V2 * animInfo.g, animInfo.r));
                    if (animInfo.b > 0.0) interpolClock = fract(GameTime * V2 * animInfo.g);
                    float v_offset = (V1 * 2.0) / atlasSize.y * timer;
                    nextFrame = coords;
                    coords.y += v_offset;
                    nextFrame.y += (V1 * 2.0) / atlasSize.y * mod(timer + 1.0, animInfo.r);
                }
                break;
            }
        }

        if (textureProperties.g == 1.0) {
            if (textureProperties.r > 1.0) {
                vtc = tint;
            } else if (textureProperties.r == 1.0) {
                float alpha = texture(Sampler0, vec2(coords.x + h_offset, coords.y)).a;
                if (alpha != 0.0) vtc = tint * alpha;
            }
        } else if (textureProperties.g == 0.0) {
            if (textureProperties.r > 1.0) {
                vtc = vec4(1.0);
            } else if (textureProperties.r == 1.0) {
                float alpha = texture(Sampler0, vec2(coords.x + h_offset, coords.y)).a;
                vtc = alpha != 0.0 ? vec4(alpha) : fadeWhiteLight;
            } else {
                vtc = fadeWhiteLight;
            }
        } else {
            vtc = fadeWhiteLight;
        }

        vec4 armor = mix(texture(Sampler0, coords), texture(Sampler0, nextFrame), interpolClock);
        vec4 color = armor * (coords.x < (1.0 / armorAmount) ? faceVertexColor : vtc) * ColorModulator;
        if (color.a < 0.1) discard;
        fadeEmitCustom(color);
        return;
    }

    vec4 color = texture(Sampler0, texCoord0);
#ifdef OIT_ADDITIVE
    color.a = min(0.99, color.a);
#endif
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) discard;
#endif
#ifdef DISSOLVE
    if (faceVertexColor.a < texture(DissolveMaskSampler, texCoord0).a) discard;
    faceVertexColor.a = 1.0;
#endif
    color *= faceVertexColor * ColorModulator;
#ifdef GLINT
    color.a = max(color.a, GlintAlpha);
#endif
#ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
#else
    fragColor = fadeFinalColor(color);
#endif
}
