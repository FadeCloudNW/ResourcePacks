#ifndef TEXT_EFFECT
#define TEXT_EFFECT(r,g,b) void f()
#endif

TEXT_EFFECT(240, 240, 0) {
    apply_shaking_movement();
    override_text_color(rgb(255, 82, 82));
    override_shadow_color(rgb(100, 20, 80));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 4) {
    apply_waving_movement();
    override_text_color(rgb(255, 235, 60));
    override_shadow_color(rgb(150, 60, 30));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 8) {
    apply_iterating_movement();
    override_text_color(rgb(86, 235, 86));
    override_shadow_color(rgb(20, 80, 90));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 12) {
    apply_flipping_movement();
    override_text_color(rgb(74, 222, 209));
    override_shadow_color(rgb(37, 71, 150));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 16) {
    apply_skewing_movement();
    override_text_color(rgb(122, 80, 251));
    override_shadow_color(rgb(40, 40, 140));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 20) {
    override_text_color(rgb(255, 82, 82));
    apply_outline(rgb(100, 20, 80));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 24) {
    apply_gradient(rgb(255, 235, 120), rgb(255, 82, 82));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 28) {
    apply_rainbow();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 32) {
    override_text_color(rgb(86, 235, 86));
    override_shadow_color(rgb(20, 80, 90));
    apply_shimmer();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 36) {
    override_text_color(rgb(255, 255, 255));
    apply_chromatic_abberation();
    remove_text_shadow();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 40) {
    apply_metalic(rgb(160, 160, 200));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 44) {
    override_text_color(rgb(255, 20, 20));
    apply_fire();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 48) {
    apply_growing_movement();
    override_text_color(rgb(255, 82, 82));
    override_shadow_color(rgb(100, 20, 80));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 52) {
    override_text_color(rgb(255, 235, 60));
    override_shadow_color(rgb(150, 60, 30));
    apply_fade(rgb(86, 235, 86));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 56) {
    override_text_color(rgb(86, 235, 86));
    override_shadow_color(rgb(20, 80, 90));
    apply_blinking();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 60) {
    override_text_color(rgb(74, 222, 209));
    override_shadow_color(rgb(37, 71, 150));
    apply_glowing();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 64) {
    apply_lesbian_pride();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 68) {
    apply_mlm_pride();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 72) {
    apply_bisexual_pride();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 76) {
    apply_transgender_pride();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 80) {
    apply_pride();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 84) {
    apply_pansexual_pride();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 88) {
    apply_asexual_pride();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 92) {
    apply_aromantic_pride();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 96) {
    apply_non_binary_pride();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 100) { // green
    apply_animated_gradient_3(rgb(0, 230, 118), rgb(118, 255, 3), rgb(178, 255, 89));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 104) { // blue
    apply_animated_gradient_3(rgb(41, 121, 255), rgb(24, 255, 255), rgb(132, 255, 255));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 108) { // yellow
    apply_animated_gradient_3(rgb(255, 145, 0), rgb(255, 255, 0), rgb(255, 255, 141));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 112) { // purple
    apply_animated_gradient_3(rgb(101, 31, 255), rgb(83, 109, 254), rgb(179, 136, 255));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 116) { // red
    apply_animated_gradient_3(rgb(213, 0, 0), rgb(245, 0, 87), rgb(255, 138, 128));
    textData.shouldScale = true;
}

// TEXT_EFFECT(240, 240, 120) { // pink fractal
//     apply_pink_fractal();
//     textData.shouldScale = true;
// }

// TEXT_EFFECT(240, 240, 124) { // bubble lime
//     apply_animated_gradient_7(rgb(118, 255, 3), rgb(112, 248, 89), rgb(105, 240, 174), rgb(136, 248, 205), rgb(167, 255, 235), rgb(193, 247, 190), rgb(219, 238, 145));
//     textData.shouldScale = true;
// }

// TEXT_EFFECT(240, 240, 128) { // galaxy lure
//     apply_animated_gradient_7(rgb(101, 31, 255), rgb(163, 48, 253), rgb(224, 64, 251), rgb(229, 96, 252), rgb(234, 128, 252), rgb(245, 128, 212), rgb(255, 128, 171));
//     textData.shouldScale = true;
// }

// TEXT_EFFECT(240, 240, 132) { // bubble lime smoother
//     apply_animated_gradient_7_smoother(rgb(118, 255, 3), rgb(112, 248, 89), rgb(105, 240, 174), rgb(136, 248, 205), rgb(167, 255, 235), rgb(193, 247, 190), rgb(219, 238, 145));
//     textData.shouldScale = true;
// }

// TEXT_EFFECT(240, 240, 136) { // galaxy lure smoother 
//     apply_animated_gradient_7_smoother(rgb(101, 31, 255), rgb(163, 48, 253), rgb(224, 64, 251), rgb(229, 96, 252), rgb(234, 128, 252), rgb(245, 128, 212), rgb(255, 128, 171));
//     textData.shouldScale = true;
// }

TEXT_EFFECT(240, 240, 120) { // green/lime/white-ish
    apply_animated_gradient_3(rgb(130, 245, 68), rgb(161, 250, 226), rgb(199, 240, 171));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 124) { // red/magenta/light blue (cyan)
    apply_animated_gradient_3(rgb(246, 79, 89), rgb(196, 113, 237), rgb(18, 194, 233));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 128) { // red/blue
    apply_animated_gradient(rgb(185, 43, 39), rgb(21, 101, 192));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 132) { // red/dark gray
    apply_animated_gradient(rgb(221, 24, 24), rgb(51, 51, 51));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 136) { // dark orange/light orange
    apply_animated_gradient(rgb(200, 50, 0), rgb(254, 140, 0));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 140) { // dark purple/red
    apply_animated_gradient(rgb(75, 9, 122), rgb(195, 20, 50));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 144) { // pale blue/pale magenta
    apply_animated_gradient(rgb(231, 85, 85), rgb(248, 197, 252));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 148) { // icy rain
    apply_animated_gradient_7_smoother(rgb(173, 216, 230), rgb(135, 206, 235), rgb(0, 206, 209), rgb(64, 224, 208), rgb(0, 191, 255), rgb(175, 238, 238), rgb(176, 224, 230));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 152) { // magenta (pale)/pink/pale orange
    apply_animated_gradient_3(rgb(167, 112, 239), rgb(207, 139, 243), rgb(253, 185, 155));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 156) { // pale orange/magenta/cyan
    apply_animated_gradient_3(rgb(254, 172, 94), rgb(199, 121, 208), rgb(75, 192, 200));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 160) { // lime/light orange
    apply_animated_gradient(rgb(49, 222, 22), rgb(255, 194, 28));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 164) { // pink/sky blue
    apply_animated_gradient(rgb(255, 145, 233), rgb(143, 213, 255));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 168) { // peach orange, light purple
    apply_animated_gradient(rgb(251, 183, 183), rgb(142, 76, 143));
    textData.shouldScale = true;
}


TEXT_EFFECT(240, 240, 172) { // pale lime, light magenta, purple
    apply_animated_gradient_3(rgb(89, 193, 115), rgb(161, 127, 224), rgb(93, 38, 193));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 176) { // light magenta, purple
    apply_animated_gradient(rgb(182, 112, 244), rgb(118, 64, 227));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 180) { // blue, purple, light cyan
    apply_animated_gradient_3(rgb(26, 60, 210), rgb(106, 31, 214), rgb(121, 239, 244));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 184) { // light blue, light green
    apply_animated_gradient(rgb(31, 220, 253), rgb(71, 251, 34));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 188) { // golden shower
    apply_animated_gradient_7_smoother(rgb(255, 215, 0), rgb(255, 223, 0), rgb(255, 193, 37), rgb(218, 165, 32), rgb(240, 230, 140), rgb(255, 239, 213), rgb(184, 134, 11));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 192) { // candy cane
    apply_animated_gradient_7_smoother(rgb(255, 0, 0), rgb(255, 182, 193), rgb(220, 20, 60), rgb(255, 192, 203), rgb(255, 105, 180), rgb(240, 128, 128), rgb(205, 92, 92));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 196) { // light orange, white shade, light blue
    apply_animated_gradient_3(rgb(232, 177, 95), rgb(221, 238, 248), rgb(92, 183, 228));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 200) { // red, orange, light orange
    apply_animated_gradient_3(rgb(181, 22, 27), rgb(229, 106, 13), rgb(253, 195, 72));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 204) { // #F0F0CC
    apply_animated_gradient_3(rgb(223, 64, 97), rgb(219, 40, 136), rgb(239, 197, 206));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 208) { // #F0F0D0
    apply_animated_gradient_3(rgb(255, 105, 180), rgb(156, 39, 176), rgb(63, 81, 181));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 212) { // #F0F0D4
    apply_animated_gradient_3(rgb(255, 255, 255), rgb(0, 255, 255), rgb(135, 206, 250));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 216) { // #F0F0D8
    apply_animated_gradient_3(rgb(243, 255, 6), rgb(228, 132, 131), rgb(213, 9, 255));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 220) { // #F0F0DC
    apply_animated_gradient(rgb(244, 242, 105), rgb(92, 178, 112));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 224) { // #F0F0E0
    apply_animated_gradient(rgb(171, 189, 255), rgb(137, 75, 119));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 228) { // #F0F0E4
    apply_animated_gradient_3(rgb(62, 25, 110), rgb(212, 108, 118), rgb(255, 192, 124));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 232) { // #F0F0E8
    apply_animated_gradient_3(rgb(255, 179, 71), rgb(255, 223, 128), rgb(255, 105, 97));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 236) { // red to blue vertical
    apply_vertical_animated_gradient(rgb(255, 50, 50), rgb(50, 50, 255));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 240) { // green to purple vertical
    apply_vertical_animated_gradient(rgb(50, 255, 50), rgb(255, 50, 255));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 244) { // orange to cyan vertical
    apply_vertical_animated_gradient(rgb(255, 150, 50), rgb(50, 255, 255));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 248) { // RGB vertical three-color
    apply_vertical_animated_gradient_3(rgb(255, 80, 80), rgb(80, 255, 80), rgb(80, 80, 255));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 240, 252) { // warm colors vertical three-color
    apply_vertical_animated_gradient_3(rgb(255, 100, 50), rgb(255, 200, 50), rgb(255, 50, 150));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 0) { // #f0f400 bubblegum swirl
    apply_marble_turbulence(rgb(26, 204, 255), rgb(230, 51, 204));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 4) { // marble ocean cyan, deep blue // tidal burst #f0f404
    apply_marble_turbulence(rgb(50, 220, 255), rgb(20, 60, 200));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 8) { // marble sunset orange, magenta
    apply_marble_turbulence(rgb(255, 160, 60), rgb(220, 60, 180));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 12) { // marble lime, purple
    apply_marble_turbulence(rgb(140, 255, 80), rgb(120, 60, 200));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 16) { // marble white, icy blue
    apply_marble_turbulence(rgb(255, 255, 255), rgb(140, 210, 255));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 20) { // marble yellow, red
    apply_marble_turbulence(rgb(255, 220, 60), rgb(210, 40, 40));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 24) { // breathing white, icy blue
    apply_breathing_colors(rgb(255, 255, 255), rgb(140, 210, 255), 0.6);
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 28) { // breathing red, yellow
    apply_breathing_colors(rgb(213, 0, 0), rgb(255, 215, 64), 0.8);
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 32) { // breathing purple, pink
    apply_breathing_colors(rgb(120, 60, 200), rgb(230, 80, 170), 1.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 36) { // breathing lime, cyan
    apply_breathing_colors(rgb(110, 240, 90), rgb(60, 220, 255), 0.7);
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 40) { // breathing gray, white
    apply_breathing_colors(rgb(120, 120, 120), rgb(255, 255, 255), 0.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 44) { // #F0F42C
    apply_animated_gradient_3(rgb(255, 255, 255), rgb(0, 255, 255), rgb(138, 43, 226));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 48) { // #F0F430
    apply_animated_gradient_3(rgb(0, 0, 0), rgb(75, 0, 130), rgb(255, 0, 83));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 52) { // #F0F434
    apply_animated_gradient_3(rgb(255, 85, 0), rgb(255, 153, 0), rgb(26, 26, 26));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 56) { // christmas candy cane #f0f438
    apply_animated_gradient_7_smoother(rgb(117, 23, 23), rgb(186, 12, 12), rgb(255, 0, 0), rgb(236, 255, 235), rgb(39, 163, 0), rgb(42, 133, 14), rgb(45, 102, 27));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 60) { // rainbow candy cane #f0f43c
    apply_animated_gradient_7_smoother(rgb(236, 255, 235), rgb(233, 32, 40), rgb(244, 111, 34), rgb(255, 224, 0), rgb(144, 199, 59), rgb(9, 136, 188), rgb(236, 255, 235));
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 68) { // aurora borealis #f0f444
    apply_animated_gradient_7_smoother(
        rgb(180, 240, 210), // icy green-white glow
        rgb(80, 220, 150),  // bright aurora green
        rgb(40, 190, 170),  // teal curtain
        rgb(60, 140, 200),  // polar blue
        rgb(120, 100, 210), // aurora purple
        rgb(90, 180, 200),  // cyan shimmer
        rgb(180, 240, 210)  // loop to glow
    );
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 72) { // diamond shimmer #f0f448
    apply_animated_gradient_7_smoother(
        rgb(255, 255, 255), // diamond white
        rgb(220, 235, 255), // icy reflection
        rgb(200, 220, 255), // blue glint
        rgb(255, 240, 250), // faint pink fire
        rgb(180, 200, 230), // silver tone
        rgb(240, 248, 255), // shimmer highlight
        rgb(255, 255, 255)  // loop
    );
    apply_shimmer();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 76) { // sweetheart swirl #f0f44c
    apply_marble_turbulence(
        rgb(255, 0, 120),   // hot pink
        rgb(255, 200, 220)  // light pink glow
    );
    textData.shouldScale = true;
}
TEXT_EFFECT(240, 244, 80) { // ruby blush #f0f450
    apply_animated_gradient_7_smoother(
        rgb(170, 0, 40),    // ruby
        rgb(210, 0, 50),    // rich red
        rgb(255, 80, 110),  // rose
        rgb(255, 170, 190), // blush highlight
        rgb(255, 80, 110),  // rose
        rgb(210, 0, 50),    // rich red
        rgb(170, 0, 40)     // loop
    );
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 84) { // shamrock glow (lighter) #f0f454
    apply_animated_gradient_7_smoother(
        rgb(40, 140, 60),   // deep shamrock
        rgb(70, 190, 90),   // clover green
        rgb(120, 235, 140), // bright shamrock
        rgb(200, 255, 210), // lucky highlight
        rgb(120, 235, 140), // bright shamrock
        rgb(70, 190, 90),   // clover green
        rgb(40, 140, 60)    // loop
    );
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 92) { // leprechauns gold #f0f45c
    apply_animated_gradient_7_smoother(
        rgb(200, 150, 0),  // light gold shadow
        rgb(220, 170, 0),  // warm gold
        rgb(245, 200, 20), // rich gold
        rgb(255, 225, 60), // bright gold
        rgb(245, 200, 20), // rich gold
        rgb(220, 170, 0),  // warm gold
        rgb(200, 150, 0)   // loop
    );
    apply_shimmer();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 96) { // irish pride #f0f460
    apply_animated_gradient_7_smoother(
        rgb(0, 150, 70),    // irish green
        rgb(120, 200, 140), // lighter green
        rgb(245, 245, 245), // soft white
        rgb(255, 150, 60),  // bright orange
        rgb(255, 120, 40),  // deep orange
        rgb(245, 245, 245), // soft white
        rgb(0, 150, 70)     // loop
    );
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 100) { // #f0f464 peep shimmer
    apply_marble_turbulence(rgb(255, 100, 255), rgb(255, 255, 100));
    apply_shimmer();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 104) { // #f0f468 pastel spectrum
    apply_pastel_rainbow_fractal();
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 112) { // beachball wave #f0f470
    apply_animated_gradient_7(
        rgb(255, 60, 60),   // red panel
        rgb(255, 245, 245), // white divider
        rgb(255, 220, 40),  // yellow panel
        rgb(255, 245, 245), // white divider
        rgb(40, 140, 255),  // blue panel
        rgb(255, 245, 245), // white divider
        rgb(255, 60, 60)    // loop
    );
    textData.shouldScale = true;
}

TEXT_EFFECT(240, 244, 116) { // tropical blast #f0f474
    apply_animated_gradient_7_smoother(
        rgb(255, 255, 170),  // sun highlight
        rgb(255, 230, 120),  // warm yellow
        rgb(255, 190, 90),   // golden orange
        rgb(255, 170, 140),  // sunset bridge
        rgb(120, 255, 220),  // tropical aqua
        rgb(70, 220, 200),   // lagoon teal
        rgb(30, 170, 180)    // deep ocean teal
    );
    textData.shouldScale = true;
}

TEXT_EFFECT(94, 171, 136) {
    apply_waving_movement(1.0, 1.5);
    apply_gradient(rgb(189, 221, 100), rgb(50, 117, 132));
    override_shadow_color(rgb(70, 70, 100));
    textData.shouldScale = true;
}

TEXT_EFFECT(255, 255, 248) {
    apply_vertical_shadow();
    apply_metalic(rgb(255, 255, 255), rgb(150, 163, 177) * 0.95);
    override_shadow_color(rgb(70, 70, 100));
    textData.shouldScale = true;
}