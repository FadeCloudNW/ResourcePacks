# FadeCloud Network Resource Pack
**Format - custom items:**  
```yml
custom_item_name
vanilla_item_override: custom_model_data_number
```

**Format - custom icons/unicodes:**  
```yml
icon_name
font: unicode
character: char
```

## Valentine 2024 Set
```yml
valentine_2024_crossbow
crossbow: 1

valentine_2024_bow
bow: 1

valentine_2024_fishing_rod
fishing_rod: 1

valentine_2024_shovel
shovel: 1

valentine_2024_shield
shield: 1

valentine_2024_helmet
leather_helmet: 1
color: FFFFFE
command: /give @s leather_helmet{CustomModelData:1,display:{color:16777214}}

valentine_2024_chestplate
leather_chestplate: 1
color: FFFFFE
command: /give @s leather_chestplate{CustomModelData:1,display:{color:16777214}}

valentine_2024_leggings
leather_leggings: 1
color: FFFFFE
command: /give @s leather_leggings{CustomModelData:1,display:{color:16777214}}

valentine_2024_boots
leather_boots: 1
color: FFFFFE
command: /give @s leather_boots{CustomModelData:1,display:{color:16777214}}
```

## New Items
```yml
green_scroll
paper: 8

red_scroll
paper: 9

yellow_scroll
paper: 10

blue_shard
paper: 11

green_shard
paper: 12

white_shard
paper: 13
```

## Inferno Set
```yml
inferno_bow
bow: 2

inferno_crossbow
crossbow: 2

inferno_fishing_rod
fishing_rod: 2

inferno_helmet_3d
carved_pumpkin: 104

inferno_shield
shield: 2

inferno_shovel
shovel: 2

inferno_axe
netherite_axe: 11

inferno_helmet
leather_helmet: 2
color: FFFFFD
command: /give @s leather_helmet{CustomModelData:2,display:{color:16777213}}

inferno_chestplate
leather_chestplate: 2
color: FFFFFD
command: /give @s leather_chestplate{CustomModelData:2,display:{color:16777213}}

inferno_leggings
leather_leggings: 2
color: FFFFFD
command: /give @s leather_leggings{CustomModelData:2,display:{color:16777213}}

inferno_boots
leather_boots: 2
color: FFFFFD
command: /give @s leather_boots{CustomModelData:2,display:{color:16777213}}
```

## Saint Patricks 2024 Set
```yml
stpatrick_2024_bow
bow: 3

stpatrick_2024_crossbow
crossbow: 3

stpatrick_2024_fishing_rod
fishing_rod: 3

stpatrick_2024_axe
netherite_axe: 8

stpatrick_2024_hammer
netherite_sword: 63

stpatrick_2024_knife
netherite_sword: 64

stpatrick_2024_spear
netherite_sword: 65

stpatrick_2024_staff
netherite_staff: 66

stpatrick_2024_sword
netherite_sword: 67

stpatrick_2024_trident
netherite_sword: 68

stpatrick_2024_hoe
netherite_hoe: 11

stpatrick_2024_scythe
netherite_hoe: 12

stpatrick_2024_pickaxe
netherite_pickaxe: 47

stpatrick_2024_shovel
netherite_shovel: 3

stpatrick_2024_hat
carved_pumpkin: 105

stpatrick_2024_chest
carved_pumpkin: 10009

stpatrick_2024_key
tripwire_hook: 1

stpatrick_2024_shield
shield: 3

stpatrick_2024_backpack
chest: 17

stpatrick_2024_wings
chest: 18

stpatrick_2024_helmet
leather_helmet: 3
color: FFFFFC
command: /give @s leather_helmet{CustomModelData:3,display:{color:16777212}}

stpatrick_2024_chestplate
leather_chestplate: 3
color: FFFFFC
command: /give @s leather_chestplate{CustomModelData:3,display:{color:16777212}}

stpatrick_2024_leggings
leather_leggings: 3
color: FFFFFC
command: /give @s leather_leggings{CustomModelData:3,display:{color:16777212}}

stpatrick_2024_boots
leather_boots: 3
color: FFFFFC
command: /give @s leather_boots{CustomModelData:3,display:{color:16777212}}
```

## April 2024 Icons and GUIs update 1
```yml
common_text
default: \uE045
character: 

common_stars
default: \uE046
character: 

rare_text
default: \uE047
character: 

rare_stars
default: \uE048
character: 

epic_text
default: \uE04D
character: 

epic_stars
default: \uE04E
character: 

legendary_text
default: \uE04F
character: 

legendary_stars
default: \uE050
character: 


star_1
default: \uE051
character: 

star_2
default: \uE052
character: 

star_3
default: \uE053
character: 

star_4
default: \uE054
character: 

star_5
default: \uE055
character: 

star_6
default: \uE056
character: 

star_7
default: \uE057
character: 

star_8
default: \uE058
character: 

star_9
default: \uE059
character: 

star_10
default: \uE05A
character: 
```

### GUIs
```yml
skulls_gui
default: \uE800
character: 
```

```yml
empty_item
paper: 14
```

## April 2024 Icons and GUIs update 2
### GUIs
```yml
game_worlds_gui
default: \uE802
character: 

leaderboards_gui
default: \uE803
character: 

storage_gui
default: \uE804
character: 

units_gui
default: \uE805
character: 
```

### Items
```yml
crystal_trait
paper: 15

diamond_trait
paper: 16

locked_red
paper: 17

unlocked_green
paper: 18
```

### Rarities
```yml
mythical_text
default: \uE070
character: 

shiny_text
default: \uE071
character: 
```

## April 2024 Icons update 3
### Unicodes
```yml
s
default: \uE072
character: 

ss
default: \uE073
character: 

sss
default: \uE074
character: 

a
default: \uE075
character: 

a_plus
default: \uE076
character: 

a_minus
default: \uE077
character: 

b
default: \uE078
character: 

b_plus
default: \uE079
character: 

b_minus
default: \uE07A
character: 

c
default: \uE07B
character: 

c_plus
default: \uE07C
character: 

c_minus
default: \uE07D
character: 
```

### Items
```yml
gem_shard
paper: 19

perfect_cube
paper: 20

stats_cube
paper: 21

token_shard
paper: 22
```

### Armor Icons
```yml
common_warrior_boots
paper: 23

common_warrior_gauntlet
paper: 24

common_warrior_helmet
paper: 25

common_warrior_chestplate
paper: 26

common_warrior_leggings
paper: 27


rare_warrior_boots
paper: 28

rare_warrior_gauntlet
paper: 29

rare_warrior_helmet
paper: 30

rare_warrior_chestplate
paper: 31

rare_warrior_leggings
paper: 32


epic_warrior_boots
paper: 33

epic_warrior_gauntlet
paper: 34

epic_warrior_helmet
paper: 35

epic_warrior_chestplate
paper: 36

epic_warrior_leggings
paper: 37


legendary_warrior_boots
paper: 38

legendary_warrior_gauntlet
paper: 39

legendary_warrior_helmet
paper: 40

legendary_warrior_chestplate
paper: 41

legendary_warrior_leggings
paper: 42


mythical_warrior_boots
paper: 43

mythical_warrior_gauntlet
paper: 44

mythical_warrior_helmet
paper: 45

mythical_warrior_chestplate
paper: 46

mythical_warrior_leggings
paper: 47
```

### Models
```yml
ice_shard
clay_ball: 1
```

## Lightning Power Set
```yml
helmet_armor
leather_helmet: 4
color: FFFFFB
command: /give @s leather_helmet{CustomModelData:4,display:{color:16777211}}

chestplate_armor
leather_chestplate: 4
color: FFFFFB
command: /give @s leather_chestplate{CustomModelData:4,display:{color:16777211}}

leggings_armor
leather_leggings: 4
color: FFFFFB
command: /give @s leather_leggings{CustomModelData:4,display:{color:16777211}}

boots_armor
leather_boots: 4
color: FFFFFB
command: /give @s leather_boots{CustomModelData:4,display:{color:16777211}}


axe
netherite_axe: 9

hammer
netherite_sword: 69

knife
netherite_sword: 70

spear
netherite_sword: 71

staff
netherite_sword: 72

sword
netherite_sword: 73

trident
netherite_sword: 74

shovel
netherite_shovel: 4

hoe
netherite_hoe: 13

scythe
netherite_hoe: 14

pickaxe
netherite_pickaxe: 48

backpack
chest: 19

bow
bow: 4

crossbow
crossbow: 4

fishing_rod
fishing_rod: 4

helmet_hat
carved_pumpkin: 106

chest
carved_pumpkin: 10010

key
tripwire_hook: 2

shield
shield: 4

wings
chest: 20
```

### Little Crocodile Set
```yml
helmet_armor
leather_helmet: 5
color: FFFFFA
command: /give @s leather_helmet{CustomModelData:5,display:{color:16777210}}

chestplate_armor
leather_chestplate: 5
color: FFFFFA
command: /give @s leather_chestplate{CustomModelData:5,display:{color:16777210}}

leggings_armor
leather_leggings: 5
color: FFFFFA
command: /give @s leather_leggings{CustomModelData:5,display:{color:16777210}}

boots_armor
leather_boots: 5
color: FFFFFA
command: /give @s leather_boots{CustomModelData:5,display:{color:16777210}}


backpack
chest: 21

tail
chest: 22

bow
bow: 5

crossbow
crossbow: 5

hat
carved_pumpkin: 107

chest
carved_pumpkin: 10011

fishing_rod
fishing_rod: 5

key
tripwire_hook: 3

axe
netherite_axe: 10

hoe
netherite_hoe: 15

hammer
netherite_sword: 75

knife
netherite_sword: 76

spear
netherite_sword: 77

staff
netherite_sword: 78

sword
netherite_sword: 79

trident
netherite_sword: 80

pickaxe
netherite_pickaxe: 49

scythe
netherite_hoe: 16

shovel
netherite_shovel: 5

shield
shield: 5
```

## July 2024 Update
```yml
unique_text
default: \uE07E
character: 
```

## August 2024 Update
### Backpacks Plus Vol. 1
```yml
bastion_backpack
chest: 23

enchanting_table_backpack
chest: 24

illager_backpack
chest: 25

lush_backpack
chest: 26

stronghold_backpack
chest: 27

wandering_trader_backpack
chest: 28

warden_backpack
chest: 29

witch_backpack
chest: 30
```

### Tiny Masks
```yml
tiny_mask_1
carved_pumpkin: 119

tiny_mask_2
carved_pumpkin: 120

tiny_mask_3
carved_pumpkin: 121

tiny_mask_4
carved_pumpkin: 122

tiny_mask_5
carved_pumpkin: 123

tiny_mask_6
carved_pumpkin: 124

tiny_mask_7
carved_pumpkin: 125

tiny_mask_8
carved_pumpkin: 126
```

### Pickaxes Pack by MCMobs
```yml
arctic_chisel
netherite_pickaxe: 10015

crimson_cutter
netherite_pickaxe: 10016

emerald_breaker
netherite_pickaxe: 10017

golden_digger
netherite_pickaxe: 10018

granite_hammer
netherite_pickaxe: 10019

rainbow_pickaxe
netherite_pickaxe: 10020

sapphire_slicer
netherite_pickaxe: 10021

sunburst_cleaver
netherite_pickaxe: 10022

thunderstrike_pickaxe
netherite_pickaxe: 10023

violet_hammer
netherite_pickaxe: 10024
```

### Summer Hats v1.1
```yml
summer_bucket_hat
carved_pumpkin: 108

summer_shark_hat
carved_pumpkin: 109

jellyfish_hat
carved_pumpkin: 110

hot_air_balloon_hat
carved_pumpkin: 111

fancy_cowboy_hat
carved_pumpkin: 112

corn_stalk_straw_hat
carved_pumpkin: 113

watermelon_hat
carved_pumpkin: 114

treasure_bag_hat
carved_pumpkin: 115

tiki_mask_hat
carved_pumpkin: 116

surf_board_hat
carved_pumpkin: 117
```

### Heaven Set
```yml
helmet_armor
leather_helmet: 6
color: 91D4EC
command: /give @s leather_helmet{CustomModelData:6,display:{color:9557228}}
new_command: /give @s leather_helmet[custom_model_data=6, dyed_color={rgb:9557228}]


chestplate_armor
leather_chestplate: 6
color: 91D4EC
command: /give @s leather_chestplate{CustomModelData:6,display:{color:9557228}}
new_command: /give @s leather_chestplate[custom_model_data=6, dyed_color={rgb:9557228}]

leggings_armor
leather_leggings: 6
color: 91D4EC
command: /give @s leather_leggings{CustomModelData:6,display:{color:9557228}}
new_command: /give @s leather_leggings[custom_model_data=6, dyed_color={rgb:9557228}]

boots_armor
leather_boots: 6
color: 91D4EC
command: /give @s leather_boots{CustomModelData:6,display:{color:9557228}}
new_command: /give @s leather_boots[custom_model_data=6, dyed_color={rgb:9557228}]


heaven_bow
bow: 6

crossbow
crossbow: 6

fishing_rod
fishing_rod: 6

heaven_helmet
carved_pumpkin: 118

heaven_chest
carved_pumpkin: 10012

heaven_key
tripwire_hook: 4

heaven_shield
shield: 6

heaven_wings
chest: 31

heaven_axe
netherite_axe: 12

heaven_hammer
netherite_axe: 13

heaven_hoe
netherite_hoe: 17

heaven_scythe
netherite_hoe: 18

heaven_pickaxe
netherite_pickaxe: 50

heaven_shovel
netherite_shovel: 6

heaven_greatsword
netherite_sword: 81

heaven_spear
netherite_sword: 82

heaven_staff
netherite_sword: 83

heaven_sword
netherite_sword: 84

heaven_trident
netherite_sword: 85
```

### Pixel Hoes
```yml
common_1_hoe
netherite_hoe: 10000

common_2_hoe
netherite_hoe: 10001

common_3_hoe
netherite_hoe: 10002

common_4_hoe
netherite_hoe: 10003

epic_1_hoe
netherite_hoe: 10004

epic_2_hoe
netherite_hoe: 10005

epic_3_hoe
netherite_hoe: 10006

epic_4_hoe
netherite_hoe: 10007

legendary_1_hoe
netherite_hoe: 10008

legendary_2_hoe
netherite_hoe: 10009

legendary_3_hoe
netherite_hoe: 10010

legendary_4_hoe
netherite_hoe: 10011

mythic_hoe
netherite_hoe: 10012

rare_1_hoe
netherite_hoe: 10013

rare_2_hoe
netherite_hoe: 10014

rare_3_hoe
netherite_hoe: 10015

rare_4_hoe
netherite_hoe: 10016
```

### Pixel Pickaxes
```yml
common_1_pick
netherite_pickaxe: 10025

common_2_pick
netherite_pickaxe: 10026

common_3_pick
netherite_pickaxe: 10027

common_4_pick
netherite_pickaxe: 10028

epic_1_pick
netherite_pickaxe: 10029

epic_2_pick
netherite_pickaxe: 10030

epic_3_pick
netherite_pickaxe: 10031

epic_4_pick
netherite_pickaxe: 10032

legendary_1_pick
netherite_pickaxe: 10033

legendary_2_pick
netherite_pickaxe: 10034

legendary_3_pick
netherite_pickaxe: 10035

legendary_4_pick
netherite_pickaxe: 10036

mythic_pick
netherite_pickaxe: 10037

rare_1_pick
netherite_pickaxe: 10038

rare_2_pick
netherite_pickaxe: 10039

rare_3_pick
netherite_pickaxe: 10040

rare_4_pick
netherite_pickaxe: 10041
```

### Pixel Swords
```yml
common_1_sword
netherite_sword: 100090

common_2_sword
netherite_sword: 100091

common_3_sword
netherite_sword: 100092

common_4_sword
netherite_sword: 100093

epic_1_sword
netherite_sword: 100094

epic_2_sword
netherite_sword: 100095

epic_3_sword
netherite_sword: 100096

epic_4_sword
netherite_sword: 100097

legendary_1_sword
netherite_sword: 100098

legendary_2_sword
netherite_sword: 100099

legendary_3_sword
netherite_sword: 100100

legendary_4_sword
netherite_sword: 100101

mythic_sword
netherite_sword: 100102

rare_1_sword
netherite_sword: 100103

rare_2_sword
netherite_sword: 100104

rare_3_sword
netherite_sword: 100105

rare_4_sword
netherite_sword: 100106
```

## August 2024 Update 2
**Synthwave Cosmetics**
```yml
cyber_dragon
carved_pumpkin: 127

cyber_skull_helmet
carved_pumpkin: 128

electronic_cat
carved_pumpkin: 129

electronic_helmet
carved_pumpkin: 130

electronic_guitar
chest: 32

electronic_keytar
chest: 33
```

**Ender Dragon Set**
```yml
helmet_armor
leather_helmet: 7
color: D6009D
command: /give @s leather_helmet{CustomModelData:7,display:{color:14024861}}
new_command: /give @s leather_helmet[custom_model_data=7, dyed_color={rgb:14024861}]

chestplate_armor
leather_chestplate: 7
color: D6009D
command: /give @s leather_chestplate{CustomModelData:7,display:{color:14024861}}
new_command: /give @s leather_chestplate[custom_model_data=7, dyed_color={rgb:14024861}]

leggings_armor
leather_leggings: 7
color: D6009D
command: /give @s leather_leggings{CustomModelData:7,display:{color:14024861}}
new_command: /give @s leather_leggings[custom_model_data=7, dyed_color={rgb:14024861}]

boots_armor
leather_boots: 7
color: D6009D
command: /give @s leather_boots{CustomModelData:7,display:{color:14024861}}
new_command: /give @s leather_boots[custom_model_data=7, dyed_color={rgb:14024861}]


bow
bow: 7

crossbow
crossbow: 7

fishing_rod
fishing_rod: 7

helmet
carved_pumpkin: 131

chest
carved_pumpkin: 10013

key
tripwire_hook: 5

shield
shield: 7

axe
netherite_axe: 14

hammer
netherite_axe: 15

pickaxe
netherite_pickaxe: 51

hoe
netherite_hoe: 19

scythe
netherite_hoe: 20

shovel
netherite_shovel: 7

gauntlet
netherite_sword: 86

spear
netherite_sword: 87

staff
netherite_sword: 88

sword
netherite_sword: 89

trident
netherite_sword: 90

wings
chest: 34
```

### Animated Gradient Color Overrides
```yml
green
hex: #f0f064

blue
hex: #f0f068

yellow
hex: #f0f06c

purple
hex: #f0f070

red
hex: #f0f074
```

### New Hats October 2024
```yml
bumble_bee_hat
carved_pumpkin: 132

flower_crown_hat
carved_pumpkin: 133

mushroom_hat2
carved_pumpkin: 134

raining_cloud_hat
carved_pumpkin: 135

sun_hat
carved_pumpkin: 136
```

## Halloween 2024 Update
### Halloween Animated Weapons and Tools Set
```yml
axe
netherite_axe: 16

hammer
netherite_axe: 17

greatsword
netherite_sword: 91

spear
netherite_sword: 92

staff
netherite_sword: 93

sword
netherite_sword: 94

trident
netherite_sword: 95

hoe
netherite_hoe: 21

scythe
netherite_hoe: 22

pickaxe
netherite_pickaxe: 52

shovel
netherite_shovel: 8

bow
bow: 8

crossbow
crossbow: 8

fishing_rod
fishing_rod: 8

helmet
carved_pumpkin: 137

chest
carved_pumpkin: 10014

key
tripwire_hook: 6

shield
shield: 8

wings
chest: 35


helmet_armor
leather_helmet: 8
color: E37D2C
command: /give @s leather_helmet{CustomModelData:8,display:{color:14908716}}
new_command: /give @s leather_helmet[custom_model_data=8, dyed_color={rgb:14908716}]

chestplate_armor
leather_chestplate: 8
color: E37D2C
command: /give @s leather_chestplate{CustomModelData:8,display:{color:14908716}}
new_command: /give @s leather_chestplate[custom_model_data=8, dyed_color={rgb:14908716}]

leggings_armor
leather_leggings: 8
color: E37D2C
command: /give @s leather_leggings{CustomModelData:8,display:{color:14908716}}
new_command: /give @s leather_leggings[custom_model_data=8, dyed_color={rgb:14908716}]

boots_armor
leather_boots: 8
color: E37D2C
command: /give @s leather_boots{CustomModelData:8,display:{color:14908716}}
new_command: /give @s leather_boots[custom_model_data=8, dyed_color={rgb:14908716}]
```

### EliteCreatures Halloween Phantom Animated Weapons
```yml
axe
netherite_axe: 18

hammer
netherite_axe: 19

mace
netherite_axe: 20

dagger
netherite_sword: 96

greatsword
netherite_sword: 97

spear
netherite_sword: 98

staff
netherite_sword: 99

sword
netherite_sword: 100

hoe
netherite_hoe: 23

pickaxe
netherite_pickaxe: 53

shovel
netherite_shovel: 9

back
chest: 36

backpack
chest: 37

bow
bow: 9

crossbow
crossbow: 9

fishing_rod
fishing_rod: 9

hat
carved_pumpkin: 138

chest
carved_pumpkin: 10015

key
tripwire_hook: 7

shield
shield: 9


helmet_armor
leather_helmet: 9
color: A2D957
command: /give @s leather_helmet{CustomModelData:9,display:{color:10672471}}
new_command: /give @s leather_helmet[custom_model_data=9, dyed_color={rgb:10672471}]

chestplate_armor
leather_chestplate: 9
color: A2D957
command: /give @s leather_chestplate{CustomModelData:9,display:{color:10672471}}
new_command: /give @s leather_chestplate[custom_model_data=9, dyed_color={rgb:10672471}]

leggings_armor
leather_leggings: 9
color: A2D957
command: /give @s leather_leggings{CustomModelData:9,display:{color:10672471}}
new_command: /give @s leather_leggings[custom_model_data=9, dyed_color={rgb:10672471}]

boots_armor
leather_boots: 9
color: A2D957
command: /give @s leather_boots{CustomModelData:9,display:{color:10672471}}
new_command: /give @s leather_boots[custom_model_data=9, dyed_color={rgb:10672471}]
```